// Shakti Shield Service Worker v2.0
const CACHE_NAME = 'shakti-shield-v2';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Nunito:wght@300;400;600;700&display=swap',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
];

// Install event – cache everything
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(ASSETS.map(url => new Request(url, { mode: 'no-cors' })));
    }).catch(() => {})
  );
  self.skipWaiting();
});

// Activate – clear old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch – cache first, then network
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200 || response.type === 'error') return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => caches.match('./index.html'));
    })
  );
});

// Push Notifications (for SOS)
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : { title: '🚨 Shakti Shield Alert', body: 'Emergency alert received' };
  event.waitUntil(
    self.registration.showNotification(data.title || '🚨 Shakti Shield', {
      body: data.body || 'You have an emergency notification',
      icon: './icon-192.svg',
      badge: './icon-192.svg',
      vibrate: [200, 100, 200, 100, 200],
      tag: 'shakti-sos',
      requireInteraction: true,
      actions: [
        { action: 'call', title: '📞 Call Now' },
        { action: 'map', title: '📍 View Location' }
      ]
    })
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.openWindow('./'));
});
